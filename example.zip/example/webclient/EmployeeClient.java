package com.example.webclient;

import com.example.restapi.Employee;

import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;


	public class EmployeeClient {
		public static void main(String[] args) {
		System.out.println("Hello World!");
	

		Vertx vertx = Vertx.vertx();

		WebClient client = WebClient.create(vertx);

		// post method

		client.post(9091, "localhost", "/addEmployee").sendJson(new Employee(1543, "Rakesh", "CIVIL", 990000),
				response -> {
					if (response.succeeded()) {
						HttpResponse<Buffer> httpResponse = response.result();
						System.out.println(" Post Response : " + response.result());
					} else {
						System.out.println("ERROR : " + response.cause().getMessage());
					}
				});

		// Get Method

		client.get(9091, "localhost", "/getEmployees").send(response -> {
			if (response.succeeded()) {
				HttpResponse<Buffer> httpResponse = response.result();
				System.out.println("GET Response : " + httpResponse.bodyAsString());
			} else {
				System.out.println("ERROR : " + response.cause().getMessage());
			}
		});

		// Get method with Filter parameter

		client.get(9091, "localhost", "/getEmployee/:name").setQueryParam("name", "Rakesh").send(response -> {
			if (response.succeeded()) {
				HttpResponse<Buffer> httpResponse = response.result();
				System.out.println("GET Response With Filter: " + httpResponse.bodyAsString());
			} else {
				System.out.println("ERROR : " + response.cause().getMessage());
			}
		});
	}
}