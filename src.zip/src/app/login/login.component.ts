import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   loginForm: FormGroup | undefined;
   submitted = false;
  login: any;
 constructor(private _route:Router){}

  ngOnInit(): void {
    username:['',Validators.required]
    password:['',Validators.required]
  }
 onSubmit(){
   
   this._route.navigate([`dashboard`]);
   }
 
}
