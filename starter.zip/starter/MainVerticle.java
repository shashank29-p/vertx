package com.example.starter;


import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Promise;

public class MainVerticle extends AbstractVerticle {



    @Override
    public void start(Promise<Void> prom) throws Exception {
        System.out.println("BasicVerticle started");
    }

    @Override
    public void stop(Promise<Void> prom) throws Exception {
        System.out.println("BasicVerticle stopped");
    }
}
