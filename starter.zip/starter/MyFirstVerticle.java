package com.example.starter;

import java.util.concurrent.Future;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;



public class MyFirstVerticle extends AbstractVerticle {

	
	  public void start(Promise<Void> prom) {
		
	   
		  vertx.createHttpServer()
	        .requestHandler(r -> {
	          r.response().end("<h1>Hello from my first " +
	              "Vert.x 3 application</h1>");
	        })
	        .listen(8080, result -> {
	          if (result.succeeded()) {
	         prom.complete();
	          } else {
	         System.out.println("hai");
	          }
	        });
	  }
	}