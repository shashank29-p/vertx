package com.example.starter.buffer;

import java.io.UnsupportedEncodingException;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.buffer.Buffer;

public class main {
	public static void main(String[] args) throws UnsupportedEncodingException {
		Buffer buffer = Buffer.buffer();
		// creating buffer array
		byte[] initialData = new byte[] { 1, 2, 3, 4, 5 };
		byte[] raw = new byte[] { 1, 2, 3, 4, 5 };
		Buffer buffer1 = Buffer.buffer(initialData);
		Buffer buffer2 = Buffer.buffer(raw);
		
		System.out.println("buffer = " + buffer1.equals(buffer2));
		System.out.println("bufferbyte = " + buffer1.getByte(2));
		System.out.println("buffer1.getBuffer() = " + buffer1.getBuffer(0, 4));
		System.out.println("buffer.setBuffer() = " + buffer1.setBuffer(1, buffer2));

		System.out.println("buffer.slice() = " + buffer1.slice(0, 3));
		System.out.println("buffer.hashcode() = " + buffer1.hashCode());
		System.out.println("buffer.append() = " + buffer1.appendBuffer(buffer2));

	
	}

}
