package com.example.starter.buffer;

import io.vertx.core.buffer.Buffer;

public class writing {
	public static void main(String[] args) {

		// creating buffer
		Buffer buffer = Buffer.buffer();

		System.out.println("buffer initial length = " + buffer.length());
		// writing to buffer
		// syntax:setInt(int pos,int i)
		// buffer.setByte ( 1, (byte) 127);
		buffer.setInt(1, 123);
		// buffer.setDouble (9, 12.0);
		buffer.setString(0, "hello");
		// syntax:append(int i)
		// buffer.appendInt(128);

		// reading from buffer
		System.out.println("buffer after writing=" + buffer.length());
		int anInt = buffer.getInt(1);
		System.out.println("value of getInt=" + anInt);
		String s = buffer.getString(0, 5);
		System.out.println("string buffer values=" + s);
		// double aByte = buffer.getDouble(9);
		// System.out.println(aByte);

	}
}