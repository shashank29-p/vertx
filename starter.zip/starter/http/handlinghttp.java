package com.example.starter.http;



import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientResponse;

//handling http response

public class handlinghttp {
public static void main(String[] args) {
	Vertx vertx=Vertx.vertx();
	HttpClient httpclient =  vertx.createHttpClient();

	httpclient.get(80, "tutorials.jenkov.com", "/", new Handler<HttpClientResponse>() {

	   
	    public void handle(HttpClientResponse httpClientResponse) {

	        httpClientResponse.bodyHandler(new Handler<Buffer>() {
	            @Override
	            public void handle(Buffer buffer) {
	                System.out.println("Response (" + buffer.length() + "): ");
	                System.out.println(buffer.getString(0, buffer.length()));
	            }
	        });
	    }
	});
}
}