package com.example.starter.http;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClient;
import io.vertx.ext.web.client.WebClient;
//http client method
public class httpclient {
	public static void main(String[] args) {
		Vertx vertx=Vertx.vertx();
		HttpClient httpclient = vertx.createHttpClient();
		WebClient client = WebClient.create(vertx);
    


		// Send a GET request
		client
		.get(80, "www.google.com", "https://www.google.com/search?client=firefox-b-d&q=facebook")
		.send()
		.onSuccess(response -> System.out
		.println("Received response with status code" + response.statusCode()))
		.onFailure(err ->
		System.out.println("Something went wrong " + err.getMessage()));
	}
}
