package com.example.starter.http;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientResponse;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;

public class httpmethod {
	public static void main(String[] args) {
	

		
	
	 
		  Vertx vertx = Vertx.vertx(); 
		  String body = "";
		    HttpServer client = vertx.createHttpServer();

		    ((HttpClient) client).request(HttpMethod.POST, "some-uri")
		      .onSuccess(request -> {
		        request.response().onSuccess(response -> {
		          System.out.println("Received response with status code " + response.statusCode());
		        });

		        // Now do stuff with the request
		        request.putHeader("content-length", "1000");
		        request.putHeader("content-type", "text/plain");
		        request.write(body);

		        // Make sure the request is ended when you're done with it
		      
		    });

	  }
}