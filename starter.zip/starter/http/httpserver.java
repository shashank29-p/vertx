package com.example.starter.http;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerRequest;

public class httpserver extends AbstractVerticle {
	   
    private HttpServer httpserver = null;

    @Override
    public void start() throws Exception {
        httpserver = vertx.createHttpServer();

        httpserver.requestHandler(new Handler<HttpServerRequest>() {
           
            public void handle(HttpServerRequest request) {
                System.out.println("incoming request!");
            }
        });

        httpserver.listen(9999);
    }
}