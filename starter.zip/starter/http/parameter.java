package com.example.starter.http;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Handler;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.ext.web.Router;



public class parameter extends AbstractVerticle {



private HttpServer httpServer = null;




@Override
public void start() throws Exception {
httpServer = vertx.createHttpServer();



httpServer.requestHandler(new Handler<HttpServerRequest>() {
@Override
public void handle(HttpServerRequest request) {
System.out.println("incoming request!");

request.uri();
request.path();
request.getParam("p1");
}
});



httpServer.listen(9999);
}
}