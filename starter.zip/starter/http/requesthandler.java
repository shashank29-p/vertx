package com.example.starter.http;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpServerRequest;

public class requesthandler extends AbstractVerticle {
	@Override
	public void start()  {
		vertx.createHttpServer().requestHandler(request -> {
			request.response().end("Hello world");
		}).listen(8192);
	}

}