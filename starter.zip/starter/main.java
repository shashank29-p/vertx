package com.example.starter;

import io.vertx.core.DeploymentOptions;
import io.vertx.core.Vertx;

public class main {
	public static void main(String args[]) throws Exception {
		Vertx vertx=Vertx.vertx();
		MainVerticle mv=new MainVerticle();
		DeploymentOptions deploymentOptions = new DeploymentOptions();
	    deploymentOptions.setInstances(1);            
	    vertx.deployVerticle(new MainVerticle(), deploymentOptions, res -> {
	            if (res.succeeded()) {
	                String deploymentId = res.result();
	                System.out.println("Deployment id is: " + deploymentId);
	                vertx.undeploy(deploymentId);
	                vertx.undeploy(deploymentId, result -> {
	      	    	  if (res.succeeded()) {
	      	    	    System.out.println("Undeployed ok");
	      	    	  } else {
	      	    	    System.out.println("Undeploy failed!");
	      	    	  }
	      	    	});
	            } else {
	                System.out.println("Deployment failed!");
	            }
	        });
	   

}}
