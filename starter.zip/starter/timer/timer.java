package com.example.starter.timer;

import io.vertx.core.AbstractVerticle;

public class timer extends AbstractVerticle {


@Override
public void start() throws Exception {
System.out.println("PeriodicVerticle.start()");

vertx.setTimer(1000, handler->{
System.out.println("I am delayed by 1 second");
});

vertx.setPeriodic(3000, handler->{
System.out.println("I am printing every 2 seconds");

});
vertx.setTimer(7000, handler->{
System.out.println("completed");
vertx.close();
});
}
}
