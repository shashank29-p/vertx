package com.example.starter.web;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerOptions;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.ext.web.Route;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.ErrorHandler;

public class errorhandling {
	 public static void main(String[] args) {
	        Vertx vertx = Vertx.vertx();
	        Router router = Router.router(vertx);
	        router.route().path("/ok").handler(ctx -> {
	            ctx.fail(new Throwable("ok"));
	        });
	        router.route().path("/error").handler(ctx -> {
	            ctx.fail(new Throwable("error\n"));
	        });
	        router.route().failureHandler(ErrorHandler.create(vertx));

	        HttpServerOptions options = new HttpServerOptions();
	        options.setPort(3000);

	        HttpServer server = vertx.createHttpServer(options);
	        server.requestHandler(router).listen(res -> {
	            System.out.println("http server started " + res.succeeded());
	        });
	    }
	}