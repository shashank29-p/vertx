package com.example.starter.web;

import java.util.function.Function;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.MultiMap;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;
import io.vertx.ext.web.client.predicate.ResponsePredicate;
import io.vertx.ext.web.client.predicate.ResponsePredicateResult;
import io.vertx.ext.web.codec.BodyCodec;

public class predicate extends AbstractVerticle {
	public static void main(String[] args) {
		
	
	
	Vertx vertx=Vertx.vertx();
	Router router = Router.router(vertx);
	WebClient client = WebClient.create(vertx);

	Function<HttpResponse<Void>, ResponsePredicateResult> methodsPredicate = resp -> {
		  String methods = resp.getHeader("Access-Control-Allow-Methods");
		  if (methods != null) {
		    if (methods.contains("POST")) {
		      return ResponsePredicateResult.success();
		    }
		  }
		  return ResponsePredicateResult.failure("Does not work");
		};

		// Send pre-flight CORS request
		client
		  .request(HttpMethod.OPTIONS, 8080, "google.com", "/login")
		  .putHeader("Origin", "Server-b.com")
		  .putHeader("Access-Control-Request-Method", "POST")
		  .expect(methodsPredicate)
		  .send(ar -> {
		    if (ar.succeeded()) {
		      // Process the POST request now
		    } else {
		      System.out.println("Something went wrong " + ar.cause().getMessage());
		    }
		  });
		}
}
