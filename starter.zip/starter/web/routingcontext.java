package com.example.starter.web;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;

public class routingcontext {
	  public static void main(String[] args) {
		    Vertx vertx = Vertx.vertx();
		    Router router = Router.router(vertx);
		    
		    router.get("/ret")
		        .handler(routingcontext -> {	        
		          JsonObject json = new JsonObject()
			                .put("message", "hello");
		          JsonObject jsons = new JsonObject()
			                .put("message", "hai");
		          routingcontext.response()
		            .setChunked(true)
		            .setStatusCode(200)
		            .end(json.toBuffer());
		         
		        });
		    
		    vertx
		      .createHttpServer()
		      .requestHandler(router)
		      .listen(8060);
		  }
		}