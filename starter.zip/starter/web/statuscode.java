package com.example.starter.web;

import io.vertx.core.AbstractVerticle;
import io.vertx.ext.web.Router;

public class statuscode extends AbstractVerticle{
	
		 @Override
		 public void start() {
		  Router router = Router.router(vertx);
		  router.get("/").handler(rc -> {
		   String param = rc.request().getParam("name");
		   if (param == null) {
		    param = "world";
		   }
		   vertx.eventBus().<String>send("request", param, reply -> {
		    if (reply.failed()) {
		     rc.response().setStatusCode(400).end(reply.cause().getMessage());
		    } else {
		     String content =  reply.result().body();
		     rc.response().end(content);
		    }
		   });
		  });

		  vertx.createHttpServer()
		    .requestHandler(router)
		    .listen(8080);

		 }
		
	}

