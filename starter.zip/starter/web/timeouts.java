package com.example.starter.web;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.http.HttpClientRequest;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.impl.logging.LoggerFactory;
import io.vertx.core.logging.Logger;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.client.WebClient;

public class timeouts extends AbstractVerticle {
	
		

		Vertx vertx=Vertx.vertx();
		Router router = Router.router(vertx);
		
	
	 Logger logger=(Logger) LoggerFactory.getLogger(timeouts.class);
	 @Override
	public void start() throws Exception {
	// TODO Auto-generated method stub
	
		vertx.createHttpServer().requestHandler(req -> {
			  logger.info("serverside: got req " + req.path());
			  if (req.path().contains("slow")) {
			    vertx.setTimer(3000, h -> req.response().end("foo"));
			  } else {
			    req.response().end("foo");
			  }
			}).listen(9090);

			HttpClient client = vertx.createHttpClient();
			for (int i = 0; i < HttpClientOptions.DEFAULT_MAX_POOL_SIZE; i++) {
			  final int id = i;
			  HttpClientRequest slowRequest = client.get(9090, "localhost", "/slow/" + id, resp -> {});
			  slowRequest.setTimeout(2000);
			  slowRequest.exceptionHandler(ex -> logger.info("got exception for /slow/" + id + ": " + ex));
			  slowRequest.end();
			}
			HttpClientRequest fastRequest = client.get(9090, "localhost", "/fast", resp -> {});
			fastRequest.setTimeout(2000);
			fastRequest.exceptionHandler(ex -> logger.info("got exception for /fast" + ": " + ex));
			fastRequest.end();
	}

}
